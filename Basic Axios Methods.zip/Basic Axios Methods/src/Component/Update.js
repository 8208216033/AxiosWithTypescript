import React, { useEffect, useState } from 'react'
import axios from 'axios';

const Update = (props) => {
 const [post,setPost]=useState(null);
 useEffect(()=>
 {
    axios.get(`${props.url}/1`).then((response)=>
    {
        setPost(response.data)
    })
 },[]);
 const updatePost=()=>
 {
    axios.put(`${props.url}/1`,
    {
        title:"Hello world!!",
        author:"Anku"
    }).then((response)=>
    {
        setPost(response.data);
    })
 }
  return (
   <>
   <h1>{post.title}</h1>
   <p>
   { post.author}
   </p>
   <button onClick={updatePost}>Update</button>
   </>
  )
}

export default Update
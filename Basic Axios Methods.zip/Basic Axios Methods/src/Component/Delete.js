import React, { useEffect, useState } from 'react'
import axios from 'axios';
const Delete = (props) => {
  const [post ,setPost]=useState(null);
 useEffect(()=>
 {
  axios.get(`${props.url}/1`).then((response)=>
  {
    setPost(response.data);
  })
 },[]);
 const deletePost=()=>{
  axios.delete(`${props.url}/2`).then(()=>
  {
    alert("post deleted");
    setPost(null)
  })
 }
 if(!post) return "no post";

  return (
  <>
  <h1>{post.title}</h1>
  <p>{post.author}</p>
  <button onClick={deletePost}>Delete</button>
  </>
  )
}

export default Delete
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Post = (props) => {
    const [post,setPost]=useState(null);
    useEffect(()=>
    {
        axios.get(`${props.url}/1`).then((response)=>
        {
            setPost(response.data)
        })
    },[]);
    const postUser=()=>{
     axios.post(props.url,{
        title:"hii",
        author:"Ankita"
     }).then((response)=>
     {
        setPost(response.data)
     })
    };
    if(!post ) return "No Post!"
  return (
   <>
   <h1>{post.title}</h1>
   <p>{post.author}</p>
   <button onClick={postUser}>Create Post</button>
   </>
  )
}

export default Post
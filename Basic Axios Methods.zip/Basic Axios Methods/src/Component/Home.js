import React, { useEffect, useState } from 'react'
import axios from "axios";
// const client=axios.create({
//     baseURL:"http://localhost:3001/posts"
// })
const Home = (props) => {
//     const baseURL="http://localhost:3001/posts";
//     const [post,setPost]=useState();
//   useEffect(()=>
//   {
//    axios.get(baseURL).then((response)=>
//    {
//     setPost(response.data);
//     console.log(response.data.title)
//    }) ;
//   },[])
//   if(!post) return null;
//     return (
//    <>
//    <h1>{post.title}</h1>
//    </>
//   )


// const baseURL = "http://localhost:3001/posts";


  const [post, setPost] = useState(null);

  React.useEffect(() => {
    axios.get(props.url).then((response) => {
      setPost(response.data[0]);
    //   console.log(response.data[0])
    //   console.log(post)
    });
  }, []);

  if (!post) return null;

  return (
    <div>
      <h1>{post.title}</h1>
      <p>
        {post.author}
      </p>
     
    </div>
  );
}

export default Home
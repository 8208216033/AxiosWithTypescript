import React from 'react'
import Home from './Component/Home'
import Post from './Component/Post'
import Update from './Component/Update';
import Delete from './Component/Delete'
import {Routes,Route} from 'react-router-dom'
const App = () => {
  const baseURL = "http://localhost:3001/posts";
  return (
   <Routes>

    <Route exact path="/get" element={<Home url={baseURL}/>}/>
    <Route exact path="/post" element={<Post url={baseURL}/>}/>
    <Route exact path="/put" element={<Update url={baseURL}/>}/>
    <Route exact path="/delete" element={<Delete url={baseURL}/>}/>
   </Routes>
  )
}

export default App
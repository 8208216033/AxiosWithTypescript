import React from 'react'
import {Link,Routes,Route} from 'react-router-dom';
import CreateCustomer from './component/CreateCustomer';
import EditCustomer from './component/EditCustomer';
import Home from './component/Home';

const App = () => {
  return (
    <>
    <nav>
      <ul>

      <li>
        <Link to={'/'}>Home</Link>
      </li>
      <li>
        <Link to={'/create'}>Create Customer</Link>
      </li>
      </ul>
    </nav>
    <Routes>
    {/* <Route path={'/create'}  component={CreateCustomer} /> */}
    <Route  path="/create"  element={<CreateCustomer />} />
    <Route path='/'  element={<Home/>} />
    <Route path='/edit/:id'  element={<EditCustomer/>} />
    </Routes>
    
    </>
  )
}

export default App
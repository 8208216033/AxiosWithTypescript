


import React, { useEffect, useState } from 'react'
import axios from 'axios'
import {useNavigate, useParams } from 'react-router-dom';
export interface IValues{
  
  first_name:string,
  last_name:string,
  email:string
}

export interface IFormState{
  [key:string]:any;
  values:IValues[];
  submitSuccess:boolean;
  Loading:boolean;
}

const values: IValues = {
  first_name: "",
  last_name: "",
  email: "",
}
  
const EditCustomer = () => {
  const [values,setValues]=useState({}as IValues)
 const History=useNavigate();
 const id =useParams
 const handleChange=(e:any)=>
  {
   e.persist();
   setValues(values=>({
    ...values,[e.target.name]:e.target.value
   }))
     }

     useEffect(()=>
     {
      getData();
     },[]);

     const getData= async()=>
     {
      const customer=await axios.get(`http://localhost:3001/customer/${id}`)
      await setValues(customer.data)
     }
  const handleSubmit=(e:any)=>
  {
 e.persist();
 axios.patch(`http://localhost:3001/customer/${id}`,values).then(data=>[
  History('/')
 ])
  }
  return (
   <>
   <label htmlFor='first_name'>First Name</label>
   <input type="text" value={values.first_name} name="first_name" onChange={handleChange}/><br/>
   <label htmlFor='last_name'>Last Name</label>
   <input type="text" value={values.last_name} name="last_name" onChange={handleChange}/><br/>
   <label htmlFor='email'>Email</label>
   <input type="text" value={values.email} name="email" onChange={handleChange}/><br/>
   <button onClick={handleSubmit}>Save</button>
   </>
  )
}

export default EditCustomer
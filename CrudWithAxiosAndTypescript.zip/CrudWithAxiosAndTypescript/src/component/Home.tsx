import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
export interface IValues{
  id:number,
  first_name:string,
  last_name:string,
  email:string
}
const Home = () => {
  const [data,setData]=useState([] as IValues[]);
  useEffect(()=>{
    getData();
  },[])
  const getData=async()=>
  {
const customer=await axios.get("http://localhost:3001/customer");
setData(customer.data)
console.log(data)
  }

  const deleteCustomer=async(e:React.MouseEvent<HTMLButtonElement, MouseEvent>,id:number)=>
  {
   e.persist();
   await axios.delete(`http://localhost:3001/customer/${id}`).then(data=>
   {
    getData();
   })
  }
  return (
   <table>
    <thead>
      <tr>
      <th>Customer Id</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Email</th>
      </tr>

      
    </thead>
    {
      data.map(custmor=>(
        <tr key={custmor.id}>
           <td>{custmor.id}</td>
          <td>{custmor.first_name}</td>
          <td>{custmor.last_name}</td>
          <td>{custmor.email}</td>
          <Link to={`edit/${custmor.id}`}>Edit</Link>
          <button onClick={e => deleteCustomer(e, custmor.id)}>Delete User</button>
        </tr>
      ))
    }
   </table>
  )
}

export default Home
import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router';
export interface IValues{
  
  first_name:string,
  last_name:string,
  email:string
}

export interface IFormState{
  [key:string]:any;
  values:IValues[];
  submitSuccess:boolean;
  Loading:boolean;
}

const defaultValues: IValues = {
  first_name: "",
  last_name: "",
  email: "",
  }
  
const CreateCustomer = () => {
  const [values,setValues]=useState(defaultValues as IValues)
 const History=useNavigate();
 const handleChange=(e:any)=>
  {
   e.persist();
   setValues(values=>({
    ...values,[e.target.name]:e.target.value
   }))
    
    
  
  }
  const handleSubmit=(e:any)=>
  {
 e.persist();
 axios.post(`http://localhost:3001/customer`,values).then(data=>[
  History('/')
 ])
  }
  return (
   <>
   <label htmlFor='first_name'>First Name</label>
   <input type="text" value={values.first_name} name="first_name" onChange={handleChange}/><br/>
   <label htmlFor='last_name'>Last Name</label>
   <input type="text" value={values.last_name} name="last_name" onChange={handleChange}/><br/>
   <label htmlFor='email'>Email</label>
   <input type="text" value={values.email} name="email" onChange={handleChange}/><br/>
   <button onClick={handleSubmit}>Save</button>
   </>
  )
}

export default CreateCustomer